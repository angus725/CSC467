
#include "semantic.h"

int semantic_check( node *ast) {
  return 0; // failed checks
}
